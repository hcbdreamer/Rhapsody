/********************************************************************
	Rhapsody	: 7.6.1 
	Login		: Paolo
	Component	: HelloWorld 
	Configuration 	: Windows
	Model Element	: Hello
//!	Generated Date	: Thu, 14, Jun 2012  
	File Path	: HelloWorld\Windows\Hello.cpp
*********************************************************************/

//## auto_generated
#include "Hello.h"
//## package Default

//## class Hello
Hello::Hello() {
    //#[ operation Hello()
    QLabel* label = new QLabel("Hello World");
    label->show();
    //#]
}

Hello::~Hello() {
}

/*********************************************************************
	File Path	: HelloWorld\Windows\Hello.cpp
*********************************************************************/

/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: Paolo
	Component	: HelloWorld 
	Configuration 	: Windows
	Model Element	: Hello
//!	Generated Date	: Thu, 14, Jun 2012  
	File Path	: HelloWorld\Windows\Hello.h
*********************************************************************/

#ifndef Hello_H
#define Hello_H

//## dependency QLabel
#include <QLabel>
//## package Default

//## class Hello
class Hello {
    ////    Constructors and destructors    ////
    
public :

    //## operation Hello()
    Hello();
    
    //## auto_generated
    ~Hello();
};

#endif
/*********************************************************************
	File Path	: HelloWorld\Windows\Hello.h
*********************************************************************/

/*********************************************************************
	Rhapsody	: 7.6.1 
	Login		: Paolo
	Component	: HelloWorld 
	Configuration 	: Windows
	Model Element	: Windows
//!	Generated Date	: Thu, 14, Jun 2012  
	File Path	: HelloWorld\Windows\MainHelloWorld.h
*********************************************************************/

#ifndef MainHelloWorld_H
#define MainHelloWorld_H

#endif
/*********************************************************************
	File Path	: HelloWorld\Windows\MainHelloWorld.h
*********************************************************************/

/*********************************************************************
	Rhapsody	: 8.2 
	Login		: h
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: class_0
//!	Generated Date	: ����, 28, 1�� 2018  
	File Path	: DefaultComponent\DefaultConfig\class_0.h
*********************************************************************/

#ifndef class_0_H
#define class_0_H

//## auto_generated
#include <oxf\oxf.h>
//## package Default

//## class class_0
class class_0 {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    class_0();
    
    //## auto_generated
    ~class_0();
};

#endif
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\class_0.h
*********************************************************************/

/********************************************************************
	Rhapsody	: 8.2 
	Login		: h
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: class_0
//!	Generated Date	: ����, 28, 1�� 2018  
	File Path	: DefaultComponent\DefaultConfig\class_0.cpp
*********************************************************************/

//## auto_generated
#include "class_0.h"
//## package Default

//## class class_0
class_0::class_0() {
}

class_0::~class_0() {
}

/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\class_0.cpp
*********************************************************************/

/*********************************************************************
	Rhapsody	: 8.2 
	Login		: h
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Hello
//!	Generated Date	: ����, 28, 1�� 2018  
	File Path	: DefaultComponent\DefaultConfig\Hello.h
*********************************************************************/

#ifndef Hello_H
#define Hello_H

//## auto_generated
#include <oxf\oxf.h>
//## dependency QLabel
#include <QLabel>
//## package Default

//## class Hello
class Hello {
    ////    Constructors and destructors    ////
    
public :

    //## operation Hello()
    Hello();
    
    //## auto_generated
    ~Hello();
};

#endif
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Hello.h
*********************************************************************/

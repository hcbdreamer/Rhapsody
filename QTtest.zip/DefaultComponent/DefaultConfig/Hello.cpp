/********************************************************************
	Rhapsody	: 8.2 
	Login		: h
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Hello
//!	Generated Date	: ����, 28, 1�� 2018  
	File Path	: DefaultComponent\DefaultConfig\Hello.cpp
*********************************************************************/

//## auto_generated
#include "Hello.h"
//## package Default

//## class Hello
Hello::Hello() {
    //#[ operation Hello()
    QLabel* label=new QLabel("hello world");
    label->show();
    //#]
}

Hello::~Hello() {
}

/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Hello.cpp
*********************************************************************/

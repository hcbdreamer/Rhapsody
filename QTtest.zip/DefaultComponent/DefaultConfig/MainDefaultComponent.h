/*********************************************************************
	Rhapsody	: 8.2 
	Login		: h
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: DefaultConfig
//!	Generated Date	: ����, 28, 1�� 2018  
	File Path	: DefaultComponent\DefaultConfig\MainDefaultComponent.h
*********************************************************************/

#ifndef MainDefaultComponent_H
#define MainDefaultComponent_H

//## auto_generated
#include <oxf\oxf.h>
#endif
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\MainDefaultComponent.h
*********************************************************************/
